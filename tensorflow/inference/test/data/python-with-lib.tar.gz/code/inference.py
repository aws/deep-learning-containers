# Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.

import json

import dummy_module


def input_handler(data, context):
    input_data = json.loads(data.read().decode('utf-8'))
    output_data = json.dumps({'instances': input_data['x']})
    return output_data


def output_handler(data, context):
    response = json.loads(data.content.decode('utf-8'))
    response['python'] = True
    response['dummy_module'] = dummy_module.__version__
    return json.dumps(response), context.accept_header
