from autogluon.tabular import TabularDataset
from autogluon.core.dataset import TabularDataset
from autogluon.tabular import TabularPredictor
from autogluon.tabular.configs.config_helper import ConfigBuilder
import time

train_data = TabularDataset("https://autogluon.s3.amazonaws.com/datasets/Inc/train.csv")
train_data = train_data[:100]

label = "class"
metric = "accuracy"

config = ConfigBuilder().hyperparameters("toy").build()

time_start = time.time()
predictor = TabularPredictor(label=label, path="tmp/")
predictor = predictor.fit(
    train_data,
    **config,
    verbosity=2,
)
time_elapsed = time.time() - time_start
predictor.leaderboard(silent=True)
